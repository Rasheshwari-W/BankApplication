package com.ap.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ap.dto.TransactionCreateDto;
import com.ap.dto.TransactionDto;
import com.ap.entity.Account;
import com.ap.entity.Customer;
import com.ap.entity.Transaction;
import com.ap.exception.ResourceNotFoundException;
import com.ap.repo.AccountRepository;
import com.ap.repo.CustomerRepository;
import com.ap.repo.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final AccountRepository accountRepository;
    private final CustomerRepository customerRepository;
    private final TransactionRepository transactionRepository;
    private final ModelMapper modelMapper;

    public TransactionServiceImpl(AccountRepository accountRepository,
                                  CustomerRepository customerRepository,
                                  TransactionRepository transactionRepository,
                                  ModelMapper modelMapper) {
        this.accountRepository = accountRepository;
        this.customerRepository = customerRepository;
        this.transactionRepository = transactionRepository;
        this.modelMapper = modelMapper;
    }

    //  Create Debit / Credit transaction
    @Override
    @Transactional
    public TransactionDto createTransaction(Long customerId, Long accountId, TransactionCreateDto dto) {
        // Verify ownership
        boolean owns = customerRepository.existsByIdAndAccounts_Accountid(customerId, accountId);
        if (!owns) {
            throw new IllegalArgumentException("Account does not belong to this customer");
        }

        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found with id: " + accountId));

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + customerId));

        Transaction tx = modelMapper.map(dto, Transaction.class);
        tx.setDate(dto.getDate() != null ? dto.getDate() : LocalDateTime.now());

        //  Must set both
        tx.setAccount(account);
        tx.setCustomer(customer);

        switch (dto.getTranstype().toUpperCase()) {
            case "DEBIT":
                if (account.getBalance().compareTo(dto.getAmount()) < 0) {
                    throw new IllegalArgumentException("Insufficient balance for debit");
                }
                account.setBalance(account.getBalance().subtract(dto.getAmount()));
                break;
            case "CREDIT":
                account.setBalance(account.getBalance().add(dto.getAmount()));
                break;
            default:
                throw new IllegalArgumentException("Invalid transaction type: " + dto.getTranstype());
        }

        transactionRepository.save(tx);
        accountRepository.save(account);

        return modelMapper.map(tx, TransactionDto.class);
    }

    //  Transfer money
    @Override
    @Transactional
    public TransactionDto transfer(Long customerId, Long sourceAccountId, Long destinationAccountId, TransactionCreateDto dto) {
        boolean ownsSource = customerRepository.existsByIdAndAccounts_Accountid(customerId, sourceAccountId);
        if (!ownsSource) {
            throw new IllegalArgumentException("Source account does not belong to this customer");
        }

        Account source = accountRepository.findById(sourceAccountId)
                .orElseThrow(() -> new ResourceNotFoundException("Source account not found: " + sourceAccountId));

        Account dest = accountRepository.findById(destinationAccountId)
                .orElseThrow(() -> new ResourceNotFoundException("Destination account not found: " + destinationAccountId));

        Customer sourceCustomer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + customerId));

        if (source.getBalance().compareTo(dto.getAmount()) < 0) {
            throw new IllegalArgumentException("Insufficient balance in source account");
        }

        LocalDateTime when = dto.getDate() != null ? dto.getDate() : LocalDateTime.now();

        Transaction debit = Transaction.builder()
                .transtype("DEBIT")
                .amount(dto.getAmount())
                .details("Transfer to account " + dest.getAccountnumber())
                .date(when)
                .account(source)
                .customer(sourceCustomer) //  link customer
                .build();

        Customer destOwner = customerRepository.findByAccounts_Accountid(destinationAccountId)
                .orElseThrow(() -> new ResourceNotFoundException("Owner customer not found for destination account: " + destinationAccountId));

        Transaction credit = Transaction.builder()
                .transtype("CREDIT")
                .amount(dto.getAmount())
                .details("Transfer from account " + source.getAccountnumber())
                .date(when)
                .account(dest)
                .customer(destOwner) 
                .build();

        // Update balances
        source.setBalance(source.getBalance().subtract(dto.getAmount()));
        dest.setBalance(dest.getBalance().add(dto.getAmount()));

        // Save transactions
        transactionRepository.save(debit);
        transactionRepository.save(credit);

        // Save updated balances
        accountRepository.save(source);
        accountRepository.save(dest);

        return modelMapper.map(debit, TransactionDto.class); // return source side
    }

    //  Get transactions of account
    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> getTransactionsByAccount(Long accountId) {
        return transactionRepository.findByAccount_AccountidOrderByDateDesc(accountId)
                .stream().map(tx -> modelMapper.map(tx, TransactionDto.class))
                .collect(Collectors.toList());
    }

    //  Get transactions of customer
    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> getTransactionsByCustomer(Long customerId) {
        return transactionRepository.findByCustomer_IdOrderByDateDesc(customerId)
                .stream().map(tx -> modelMapper.map(tx, TransactionDto.class))
                .collect(Collectors.toList());
    }

    //  Admin: Get all
    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> getAllTransactions() {
        return transactionRepository.findAll()
                .stream().map(tx -> modelMapper.map(tx, TransactionDto.class))
                .collect(Collectors.toList());
    }
}
