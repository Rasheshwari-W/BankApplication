package com.ap.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ap.dto.TransactionCreateDto;
import com.ap.dto.TransactionDto;
import com.ap.dto.TransferRequestDto;
import com.ap.entity.Account;
import com.ap.entity.Customer;
import com.ap.entity.Transaction;
import com.ap.exception.ResourceNotFoundException;
import com.ap.exception.UnauthorizedActionException;
import com.ap.repo.AccountRepository;
import com.ap.repo.CustomerRepository;
import com.ap.repo.TransactionRepository;
import com.ap.security.CustomUserPrincipal;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final AccountRepository accountRepository;
    private final CustomerRepository customerRepository;
    private final TransactionRepository transactionRepository;
    private final ModelMapper modelMapper;

    public TransactionServiceImpl(AccountRepository accountRepository,
                                  CustomerRepository customerRepository,
                                  TransactionRepository transactionRepository,
                                  ModelMapper modelMapper) {
        this.accountRepository = accountRepository;
        this.customerRepository = customerRepository;
        this.transactionRepository = transactionRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    @Transactional
    public TransactionDto createTransaction(TransactionCreateDto dto) {
        // Find account by accountNumber
        Account account = accountRepository.findByAccountnumber(dto.getAccountNumber())
                .orElseThrow(() -> new ResourceNotFoundException(
                    "Account not found with number: " + dto.getAccountNumber()));

        Customer customer = account.getCustomer(); // directly from account

        Transaction tx = Transaction.builder()
                .transtype(dto.getTranstype())
                .amount(dto.getAmount())
                .details(dto.getDetails())
                .date(dto.getDate() != null ? dto.getDate() : LocalDateTime.now())
                .account(account)
                .customer(customer)
                .build();

        if ("DEBIT".equalsIgnoreCase(dto.getTranstype())) {
            if (account.getBalance().compareTo(dto.getAmount()) < 0) {
                throw new IllegalArgumentException("Insufficient balance for debit");
            }
            account.setBalance(account.getBalance().subtract(dto.getAmount()));
        } else if ("CREDIT".equalsIgnoreCase(dto.getTranstype())) {
            account.setBalance(account.getBalance().add(dto.getAmount()));
        } else {
            throw new IllegalArgumentException("Invalid transaction type: " + dto.getTranstype());
        }

        transactionRepository.save(tx);
        accountRepository.save(account);

        return modelMapper.map(tx, TransactionDto.class);
    }


    @Override
    @Transactional
    public TransactionDto transfer(TransferRequestDto dto) {
        if (dto.getFromAccountNumber().equals(dto.getToAccountNumber())) {
            throw new IllegalArgumentException("Source and destination accounts cannot be the same");
        }

        Account source = accountRepository.findByAccountnumber(dto.getFromAccountNumber())
                .orElseThrow(() -> new ResourceNotFoundException("Source account not found: " + dto.getFromAccountNumber()));

        Account dest = accountRepository.findByAccountnumber(dto.getToAccountNumber())
                .orElseThrow(() -> new ResourceNotFoundException("Destination account not found: " + dto.getToAccountNumber()));

        // 👇 Get logged-in user from SecurityContext
        Long loggedInUserId = ((CustomUserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal()).getId();

        Customer sourceCustomer = source.getCustomer();

        // ✅ Check ownership if not ADMIN
        boolean isAdmin = SecurityContextHolder.getContext().getAuthentication().getAuthorities()
                .stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        if (!isAdmin && !sourceCustomer.getUser().getUserid().equals(loggedInUserId)) {
            throw new UnauthorizedActionException("You do not own the source account");
        }

        if (source.getBalance().compareTo(dto.getAmount()) < 0) {
            throw new IllegalArgumentException("Insufficient balance in source account");
        }

        LocalDateTime when = LocalDateTime.now();

        // DEBIT transaction
        Transaction debit = Transaction.builder()
                .transtype("DEBIT")
                .amount(dto.getAmount())
                .details(dto.getDetails() != null ? dto.getDetails() : "Transfer to account " + dest.getAccountnumber())
                .date(when)
                .account(source)
                .customer(sourceCustomer)
                .build();

        // CREDIT transaction
        Customer destOwner = dest.getCustomer();
        Transaction credit = Transaction.builder()
                .transtype("CREDIT")
                .amount(dto.getAmount())
                .details("Transfer from account " + source.getAccountnumber())
                .date(when)
                .account(dest)
                .customer(destOwner)
                .build();

        // Update balances
        source.setBalance(source.getBalance().subtract(dto.getAmount()));
        dest.setBalance(dest.getBalance().add(dto.getAmount()));

        // Save
        transactionRepository.save(debit);
        transactionRepository.save(credit);
        accountRepository.save(source);
        accountRepository.save(dest);

        return modelMapper.map(debit, TransactionDto.class);
    }



    //  Get transactions of account
    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> getTransactionsByAccount(Long accountId) {
        return transactionRepository.findByAccount_AccountidOrderByDateDesc(accountId)
                .stream().map(tx -> modelMapper.map(tx, TransactionDto.class))
                .collect(Collectors.toList());
    }

    //  Get transactions of customer
    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> getTransactionsByCustomer(Long customerId) {
        return transactionRepository.findByCustomer_IdOrderByDateDesc(customerId)
                .stream().map(tx -> modelMapper.map(tx, TransactionDto.class))
                .collect(Collectors.toList());
    }

    //  Admin: Get all
    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> getAllTransactions() {
        return transactionRepository.findAll()
                .stream().map(tx -> modelMapper.map(tx, TransactionDto.class))
                .collect(Collectors.toList());
    }
}
