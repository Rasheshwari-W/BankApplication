package com.ap.service;



import java.util.List;

import com.ap.dto.AccountCreateDto;
import com.ap.dto.AccountDto;

public interface AccountService {
    AccountDto createAccount(Long customerId, AccountCreateDto dto);
    List<AccountDto> getAccountsByCustomer(Long customerId);
    List<AccountDto> getAllAccounts();
    AccountDto getAccountById(Long accountId);
    void deleteAccount(Long accountId);
}
