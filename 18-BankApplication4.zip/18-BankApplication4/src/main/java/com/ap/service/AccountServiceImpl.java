package com.ap.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.ap.dto.AccountCreateDto;
import com.ap.dto.AccountDto;
import com.ap.entity.Account;
import com.ap.entity.Customer;
import com.ap.exception.ResourceNotFoundException;
import com.ap.repo.AccountRepository;
import com.ap.repo.CustomerRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final CustomerRepository customerRepository;
    private final AccountRepository accountRepository;
    private final ModelMapper modelMapper;
    private final EmailService emailService;
    
    public AccountServiceImpl(CustomerRepository customerRepository,
                              AccountRepository accountRepository,
                              ModelMapper modelMapper,EmailService emailService) {
        this.customerRepository = customerRepository;
        this.accountRepository = accountRepository;
        this.modelMapper = modelMapper;
        this.emailService = emailService;
    }

    @Override
    public AccountDto createAccount(Long customerId, AccountCreateDto dto) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + customerId));

        Account account = modelMapper.map(dto, Account.class);

        // Set the relationship both ways
        account.setCustomer(customer);                
        customer.getAccounts().add(account);

        
        Account savedAccount = accountRepository.save(account);
        
        String subject = "Account Created Successfully";
        String body = String.format("Dear %s,\n\nYour account has been created successfully.\n" +
                        "Account Number: %s\nAccount Type: %s\nBalance: %s\n\nThank you for banking with us!",
                customer.getUser().getUsername(),
                savedAccount.getAccountnumber(),
                savedAccount.getAccounttype(),
                savedAccount.getBalance());

        emailService.sendEmail(customer.getEmailid(), subject, body);
        
        

        return modelMapper.map(savedAccount, AccountDto.class);
    }


    @Override
    public List<AccountDto> getAccountsByCustomer(Long customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + customerId));

        return customer.getAccounts()
                .stream()
                .map(acc -> modelMapper.map(acc, AccountDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<AccountDto> getAllAccounts() {
        return accountRepository.findAll()
                .stream()
                .map(acc -> modelMapper.map(acc, AccountDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public AccountDto getAccountById(Long accountId) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found with id: " + accountId));
        return modelMapper.map(account, AccountDto.class);
    }

    @Override
    public void deleteAccount(Long accountId) {
        if (!accountRepository.existsById(accountId)) {
            throw new ResourceNotFoundException("Account not found with id: " + accountId);
        }
        accountRepository.deleteById(accountId);
    }
}
