package com.ap.service;

import java.util.List;
import com.ap.dto.TransactionCreateDto;
import com.ap.dto.TransactionDto;

public interface TransactionService {
    TransactionDto createTransaction(Long customerId, Long accountId, TransactionCreateDto dto);
    TransactionDto transfer(Long customerId, Long sourceAccountId, Long destinationAccountId, TransactionCreateDto dto);
    List<TransactionDto> getTransactionsByAccount(Long accountId);
    List<TransactionDto> getTransactionsByCustomer(Long customerId);
    List<TransactionDto> getAllTransactions();
}
