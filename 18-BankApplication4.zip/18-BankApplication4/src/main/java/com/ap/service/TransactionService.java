package com.ap.service;

import java.util.List;

import com.ap.dto.TransactionCreateDto;
import com.ap.dto.TransactionDto;
import com.ap.dto.TransferRequestDto;

public interface TransactionService {
//    TransactionDto createTransaction(Long customerId, Long accountId, TransactionCreateDto dto);
//    TransactionDto transfer(Long customerId, Long sourceAccountId, Long destinationAccountId, TransactionCreateDto dto);
    List<TransactionDto> getTransactionsByAccount(Long accountId);
    List<TransactionDto> getTransactionsByCustomer(Long customerId);
    List<TransactionDto> getAllTransactions();
    
//    TransactionDto transfer(Long userId, TransferRequestDto request);
	TransactionDto transfer(TransferRequestDto dto);
	TransactionDto createTransaction(TransactionCreateDto dto);
}
