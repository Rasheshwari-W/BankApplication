package com.ap.service;


import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.ap.dto.PassbookDto;
import com.ap.dto.TransactionDto;
import com.ap.entity.Account;
import com.ap.exception.ResourceNotFoundException;
import com.ap.repo.AccountRepository;
import com.ap.repo.TransactionRepository;


@Service
public class PassbookServiceImpl implements PassbookService {

 private final AccountRepository accountRepository;
 private final TransactionRepository transactionRepository;
 private final ModelMapper modelMapper;

 public PassbookServiceImpl(AccountRepository accountRepository,
                            TransactionRepository transactionRepository,
                            ModelMapper modelMapper) {
     this.accountRepository = accountRepository;
     this.transactionRepository = transactionRepository;
     this.modelMapper = modelMapper;
 }

 @Override
 public PassbookDto getPassbookByAccount(Long accountId) {
     Account account = accountRepository.findById(accountId)
         .orElseThrow(() -> new ResourceNotFoundException("Account not found with id: " + accountId));

     PassbookDto passbook = new PassbookDto();
     passbook.setAccountId(account.getAccountid());
     passbook.setAccountNumber(account.getAccountnumber());
     passbook.setAccountType(account.getAccounttype());
     passbook.setBalance(account.getBalance());

     List<TransactionDto> transactions = transactionRepository
         .findByAccount_AccountidOrderByDateDesc(accountId)
         .stream()
         .map(tx -> modelMapper.map(tx, TransactionDto.class))
         .collect(Collectors.toList());

     passbook.setTransactions(transactions);
     return passbook;
 }
}


