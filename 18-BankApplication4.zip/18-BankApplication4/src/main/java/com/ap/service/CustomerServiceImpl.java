package com.ap.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.ap.dto.CustomerCreateDto;
import com.ap.dto.CustomerDto;
import com.ap.entity.Customer;
import com.ap.entity.User;
import com.ap.exception.ResourceNotFoundException;
import com.ap.repo.CustomerRepository;
import com.ap.repo.UserRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;

    public CustomerServiceImpl(CustomerRepository customerRepository,
                               UserRepository userRepository,
                               ModelMapper modelMapper) {
        this.customerRepository = customerRepository;
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }

    //  Admin creates Customer for a User
    @Override
    public CustomerDto createCustomer(Long userId, CustomerCreateDto dto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        // ensure user doesn’t already have a customer record
        if (customerRepository.findByUser_Userid(userId).isPresent()) {
            throw new IllegalArgumentException("This user already has a customer record");
        }

        Customer customer = modelMapper.map(dto, Customer.class);
        customer.setUser(user);

        Customer saved = customerRepository.save(customer);
        return modelMapper.map(saved, CustomerDto.class);
    }

    //  Get customer by ID (Admin or owner)
    @Override
    public CustomerDto getCustomerById(Long customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + customerId));
        return modelMapper.map(customer, CustomerDto.class);
    }

    //  Get all customers (Admin only)
    @Override
    public List<CustomerDto> getAllCustomers() {
        return customerRepository.findAll()
                .stream()
                .map(c -> modelMapper.map(c, CustomerDto.class))
                .collect(Collectors.toList());
    }

    //  Update customer (Admin or owner)
    @Override
    public CustomerDto updateCustomer(Long customerId, CustomerCreateDto dto) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + customerId));

        // safely map updates (ModelMapper skips nulls if configured in MapperConfig)
        modelMapper.map(dto, customer);

        Customer updated = customerRepository.save(customer);
        return modelMapper.map(updated, CustomerDto.class);
    }

    //  Delete customer (Admin only)
    @Override
    public void deleteCustomer(Long customerId) {
        if (!customerRepository.existsById(customerId)) {
            throw new ResourceNotFoundException("Customer not found with id: " + customerId);
        }
        customerRepository.deleteById(customerId);
    }
}
