package com.ap.service;



import java.util.List;

import com.ap.dto.CustomerCreateDto;
import com.ap.dto.CustomerDto;

public interface CustomerService {

    CustomerDto getCustomerById(Long id);
    List<CustomerDto> getAllCustomers();
    CustomerDto updateCustomer(Long id, CustomerCreateDto dto);
    void deleteCustomer(Long id);
    CustomerDto createCustomer(Long userId, CustomerCreateDto dto);
}
