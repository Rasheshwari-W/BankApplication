package com.ap.service;


import com.ap.dto.PassbookDto;

public interface PassbookService {
    PassbookDto getPassbookByAccount(Long accountId);
}

