package com.ap.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ap.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    // ✅ Find customer by User ID (handy for security checks)
    Optional<Customer> findByUser_Userid(Long userId);

    // ✅ Check if a customer owns a specific account
    boolean existsByIdAndAccounts_Accountid(Long customerId, Long accountId);

    // ✅ Find customer by account ID
    Optional<Customer> findByAccounts_Accountid(Long accountId);
    
    boolean existsByIdAndUser_Userid(Long customerId, Long userId);
    

}
