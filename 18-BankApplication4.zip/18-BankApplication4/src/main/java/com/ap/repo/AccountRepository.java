package com.ap.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ap.entity.Account;

public interface AccountRepository extends JpaRepository<Account, Long> {

    // ✅ Get all accounts for a customer
    List<Account> findByCustomer_Id(Long customerId);

    // ✅ Verify account belongs to a customer
    boolean existsByAccountidAndCustomer_Id(Long accountId, Long customerId);
    
   
    boolean existsByAccountidAndCustomer_User_Userid(Long accountId, Long userId);
    

	Optional<Account> findByAccountnumber(String fromAccountNumber);

}
