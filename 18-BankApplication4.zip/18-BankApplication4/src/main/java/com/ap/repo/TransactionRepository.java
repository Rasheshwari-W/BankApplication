package com.ap.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ap.entity.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    // ✅ Find all transactions by account
    List<Transaction> findByAccount_AccountidOrderByDateDesc(Long accountId);

    // ✅ Find all transactions by customer
    List<Transaction> findByCustomer_IdOrderByDateDesc(Long customerId);
    
    
 // ✅ find transactions by accountNumber
    List<Transaction> findByAccount_AccountnumberOrderByDateDesc(String accountNumber);

    // ✅ find transactions by customerId (this one can remain same)
//    LList<Transaction> findByCustomer_IdOrderByDateDesc(Long customerId);


}
