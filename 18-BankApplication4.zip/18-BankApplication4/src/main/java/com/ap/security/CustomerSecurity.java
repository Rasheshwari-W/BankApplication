package com.ap.security;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.ap.entity.Customer;
import com.ap.repo.AccountRepository;
import com.ap.repo.CustomerRepository;

@Component
public class CustomerSecurity {

    private final CustomerRepository customerRepository;
    private final AccountRepository accountRepository;

    public CustomerSecurity(CustomerRepository customerRepository, AccountRepository accountRepository) {
        this.customerRepository = customerRepository;
        this.accountRepository = accountRepository;
    }

    //  Check if logged-in user owns this customerId
    public boolean isCustomerOwner(Long customerId, Long userId) {
        return customerRepository.existsByIdAndUser_Userid(customerId, userId);
    }

    //  Check if logged-in user owns this account (via customerId)
    public boolean isAccountOwner(Long customerId, Long accountId, Long userId) {
        // First check if the account belongs to that customer
        boolean belongsToCustomer = accountRepository.existsByAccountidAndCustomer_Id(accountId, customerId);

        // Then check if that customer belongs to the logged-in user
        boolean belongsToUser = customerRepository.existsByIdAndUser_Userid(customerId, userId);

        return belongsToCustomer && belongsToUser;
    }

    // ✅Check if logged-in user owns an account directly by accountId
    public boolean isAccountOwnerByAccountId(Long accountId, Long userId) {
        return accountRepository.existsByAccountidAndCustomer_User_Userid(accountId, userId);
    }
    
    public boolean isAccountOwnerByAccountNumber(String accountNumber, Long userId) {
        return accountRepository.findByAccountnumber(accountNumber)
                .map(acc -> acc.getCustomer().getUser().getUserid().equals(userId))
                .orElse(false);
    }

}
