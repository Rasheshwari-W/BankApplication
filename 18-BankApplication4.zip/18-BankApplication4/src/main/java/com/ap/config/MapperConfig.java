package com.ap.config;



import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperConfig {
    @Bean
    public ModelMapper modelMapper() {
        ModelMapper mapper = new ModelMapper();
        // Skip nulls (good for partial updates)
        mapper.getConfiguration().setPropertyCondition(Conditions.isNotNull());

        // Examples: skip mapping DB-generated id or password from DTO -> entity
        // Type maps reference your DTO and Entity classes
        mapper.typeMap(com.ap.dto.UserCreateDto.class, com.ap.entity.User.class)
              .addMappings(m -> m.skip(com.ap.entity.User::setUserid)); // never set id from DTO

        

        return mapper;
    }
}
