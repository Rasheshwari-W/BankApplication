package com.ap.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ap.dto.PassbookDto;
import com.ap.service.PassbookService;

@RestController
@RequestMapping("/api/passbook")
public class PassbookController {

    private final PassbookService passbookService;

    public PassbookController(PassbookService passbookService) {
        this.passbookService = passbookService;
    }

    // Admin can view any passbook, Customer only their own
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isAccountOwnerByAccountId(#accountId, authentication.principal.id)")
    @GetMapping("/account/{accountId}")
    public ResponseEntity<PassbookDto> getPassbookByAccount(@PathVariable Long accountId) {
        return ResponseEntity.ok(passbookService.getPassbookByAccount(accountId));
    }
}


