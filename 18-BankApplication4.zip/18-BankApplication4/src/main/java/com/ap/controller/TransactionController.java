package com.ap.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.ap.dto.TransactionCreateDto;
import com.ap.dto.TransactionDto;
import com.ap.service.TransactionService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    // Customer can transact on own account, Admin on any
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isAccountOwner(#customerId, #accountId, authentication.principal.id)")
    @PostMapping("/customer/{customerId}/account/{accountId}")
    public ResponseEntity<TransactionDto> createTransaction(
            @PathVariable Long customerId,
            @PathVariable Long accountId,
            @Valid @RequestBody TransactionCreateDto dto) {
        return ResponseEntity.ok(transactionService.createTransaction(customerId, accountId, dto));
    }

    // Customer can transfer only from their own source account, Admin can transfer from any
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isAccountOwner(#customerId, #sourceId, authentication.principal.id)")
    @PostMapping("/customer/{customerId}/transfer/from/{sourceId}/to/{destinationId}")
    public ResponseEntity<TransactionDto> transfer(
            @PathVariable Long customerId,
            @PathVariable Long sourceId,
            @PathVariable Long destinationId,
            @Valid @RequestBody TransactionCreateDto dto) {
        return ResponseEntity.ok(transactionService.transfer(customerId, sourceId, destinationId, dto));
    }

    // Customer can view own account transactions, Admin can view any
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isAccountOwnerByAccountId(#accountId, authentication.principal.id)")
    @GetMapping("/account/{accountId}")
    public ResponseEntity<List<TransactionDto>> getTransactionsByAccount(@PathVariable Long accountId) {
        return ResponseEntity.ok(transactionService.getTransactionsByAccount(accountId));
    }

    // Customer can view their own transactions, Admin can view any
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isCustomerOwner(#customerId, authentication.principal.id)")
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<TransactionDto>> getTransactionsByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(transactionService.getTransactionsByCustomer(customerId));
    }

    // Admin only
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<List<TransactionDto>> getAllTransactions() {
        return ResponseEntity.ok(transactionService.getAllTransactions());
    }
}
