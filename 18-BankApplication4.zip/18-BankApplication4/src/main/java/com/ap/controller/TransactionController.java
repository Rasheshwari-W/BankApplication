package com.ap.controller;

import java.util.List;

import org.springframework.boot.autoconfigure.couchbase.CouchbaseProperties.Authentication;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ap.dto.TransactionCreateDto;
import com.ap.dto.TransactionDto;
import com.ap.dto.TransferRequestDto;
import com.ap.security.CustomUserPrincipal;
import com.ap.service.TransactionService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PreAuthorize("@customerSecurity.isAccountOwnerByAccountNumber(#dto.accountNumber, authentication.principal.id)")
    @PostMapping
    public ResponseEntity<TransactionDto> createTransaction(@Valid @RequestBody TransactionCreateDto dto) {
        return ResponseEntity.ok(transactionService.createTransaction(dto));
    }


    @PostMapping("/transfer")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<TransactionDto> transfer(@Valid @RequestBody TransferRequestDto dto) {
        return ResponseEntity.ok(transactionService.transfer(dto));
    }


    // Customer can view own account transactions, Admin can view any
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isAccountOwnerByAccountId(#accountId, authentication.principal.id)")
    @GetMapping("/{accountId}")
    public ResponseEntity<List<TransactionDto>> getTransactionsByAccount(@PathVariable Long accountId) {
        return ResponseEntity.ok(transactionService.getTransactionsByAccount(accountId));
    }

    // Customer can view their own transactions, Admin can view any
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isCustomerOwner(#customerId, authentication.principal.id)")
    @GetMapping("/{customerId}")
    public ResponseEntity<List<TransactionDto>> getTransactionsByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(transactionService.getTransactionsByCustomer(customerId));
    }

    // Admin only
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<List<TransactionDto>> getAllTransactions() {
        return ResponseEntity.ok(transactionService.getAllTransactions());
    }
}
