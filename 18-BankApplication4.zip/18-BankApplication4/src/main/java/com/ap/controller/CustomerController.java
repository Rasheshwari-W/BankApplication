package com.ap.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.ap.dto.CustomerCreateDto;
import com.ap.dto.CustomerDto;
import com.ap.service.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    //  Only Admin can create a new customer linked to an existing User
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{userId}")
    public ResponseEntity<CustomerDto> createCustomer(
            @PathVariable Long userId,
            @Valid @RequestBody CustomerCreateDto dto) {
        return ResponseEntity.ok(customerService.createCustomer(userId, dto));
    }

    //  Admin can fetch any customer, Customer can fetch only their own
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isCustomerOwner(#customerId, authentication.principal.id)")
    @GetMapping("/{customerId}")
    public ResponseEntity<CustomerDto> getCustomerById(@PathVariable Long customerId) {
        return ResponseEntity.ok(customerService.getCustomerById(customerId));
    }

    //  Admin can fetch all customers
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<List<CustomerDto>> getAllCustomers() {
        return ResponseEntity.ok(customerService.getAllCustomers());
    }

    //  Admin can update any customer, Customer can update only their own
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isCustomerOwner(#customerId, authentication.principal.id)")
    @PutMapping("/{customerId}")
    public ResponseEntity<CustomerDto> updateCustomer(@PathVariable Long customerId,
                                                      @Valid @RequestBody CustomerCreateDto dto) {
        return ResponseEntity.ok(customerService.updateCustomer(customerId, dto));
    }

    //  Only Admin can delete customers
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{customerId}")
    public ResponseEntity<String> deleteCustomer(@PathVariable Long customerId) {
        customerService.deleteCustomer(customerId);
        return ResponseEntity.ok("Customer deleted successfully.");
    }
}
