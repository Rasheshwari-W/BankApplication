package com.ap.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.ap.dto.AccountCreateDto;
import com.ap.dto.AccountDto;
import com.ap.service.AccountService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    private final AccountService accountService;

    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    // Admin can create accounts for customers
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{customerId}")
    public ResponseEntity<AccountDto> createAccount(@PathVariable Long customerId,
                                                    @Valid @RequestBody AccountCreateDto dto) {
        return ResponseEntity.ok(accountService.createAccount(customerId, dto));
    }

    // Customer can view own accounts, Admin can view any
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isCustomerOwner(#customerId, authentication.principal.id)")
    @GetMapping("/{customerId}")
    public ResponseEntity<List<AccountDto>> getAccountsByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(accountService.getAccountsByCustomer(customerId));
    }

    // Admin can view any account, Customer only own account
    @PreAuthorize("hasRole('ADMIN') or @customerSecurity.isAccountOwnerByAccountId(#accountId, authentication.principal.id)")
    @GetMapping("/{accountId}")
    public ResponseEntity<AccountDto> getAccountById(@PathVariable Long accountId) {
        return ResponseEntity.ok(accountService.getAccountById(accountId));
    }

    // Admin only
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{accountId}")
    public ResponseEntity<String> deleteAccount(@PathVariable Long accountId) {
        accountService.deleteAccount(accountId);
        return ResponseEntity.ok("Account deleted successfully.");
    }
}
