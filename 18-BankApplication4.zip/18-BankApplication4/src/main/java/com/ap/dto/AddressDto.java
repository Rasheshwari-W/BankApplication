package com.ap.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AddressDto {
	//private Long id;
	@NotBlank
	private String city;
	
	@NotBlank
	private String state;
	
	@NotBlank
	@Pattern(regexp = "^[1-9][0-9]{5}$", message = "pincode must be 6 digits")
	private String pincode;
}
