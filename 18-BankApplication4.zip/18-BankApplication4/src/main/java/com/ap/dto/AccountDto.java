package com.ap.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data @NoArgsConstructor @AllArgsConstructor
public class AccountDto {
// private Long accountid;
 private String accountnumber;
 private String accounttype;
 private BigDecimal balance;
// private List<TransactionDto> transactions; 
}
