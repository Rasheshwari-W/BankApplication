package com.ap.dto;




import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

@Data
public class PassbookDto {
    private Long accountId;
    private String accountNumber;
    private String accountType;
    private BigDecimal balance;
    private List<TransactionDto> transactions;
}
