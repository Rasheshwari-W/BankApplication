package com.ap.dto;

import java.math.BigDecimal;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferRequestDto {

    @NotNull
    private String fromAccountNumber;   // instead of sourceId

    @NotNull
    private String toAccountNumber;     // instead of destinationId

    @NotNull
    private BigDecimal amount;

    private String details; // optional: note for transaction
}
