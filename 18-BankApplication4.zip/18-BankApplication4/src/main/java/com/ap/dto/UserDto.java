package com.ap.dto;


import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
public class UserDto {
 private Long userid;
 private String username;
 private Set<RoleDto> roles; // no password here
}

