package com.ap.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountCreateDto {
	@NotBlank
	@Pattern(
	    regexp = "^[0-9]{11}$",
	    message = "Account number must be exactly 11 digits"
	)
	private String accountnumber;
	@NotBlank
	private String accounttype;
	@NotNull
	@DecimalMin("0.0")
	private BigDecimal balance;

}
