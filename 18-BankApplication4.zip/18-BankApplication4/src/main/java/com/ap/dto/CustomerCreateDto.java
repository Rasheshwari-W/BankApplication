package com.ap.dto;

import java.time.LocalDate;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerCreateDto {
	@Email
	@NotBlank
	private String emailid;
	
	@NotBlank
	@Pattern(regexp = "^[0-9]{10,15}$")
	private String contactno;
	
	
	@Past
	private LocalDate dob;
	
	@Valid
	@NotNull   
	private AddressDto address; // nested; controller must use @Valid

}
