package com.ap.dto;



import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class TransactionCreateDto {
    @NotBlank(message = "Transaction type is required")
    @Pattern(
        regexp = "DEBIT|CREDIT|TRANSFER",
        message = "Transaction type must be either DEBIT, CREDIT, or TRANSFER"
    )
    private String transtype;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be greater than 0")
    private BigDecimal amount;

    @Size(min = 2, max = 100, message = "Details must be between 2 and 100 characters")
    private String details;

    @NotNull(message = "Date is required")
    @PastOrPresent(message = "Transaction date cannot be in the future")
    private LocalDateTime date;
}
