package com.ap.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class TransactionCreateDto {

    @NotBlank(message = "Account number is required")
    @Pattern(regexp = "\\d{11}", message = "Account number must be 11 digits")
    private String accountNumber;

    @NotBlank(message = "Transaction type is required")
    @Pattern(regexp = "DEBIT|CREDIT", message = "Transaction type must be either DEBIT or CREDIT")
    private String transtype;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
    private BigDecimal amount;

    @Size(max = 255, message = "Details cannot be longer than 255 characters")
    private String details;

    private LocalDateTime date; // optional, defaults in service
}
