package com.ap.dto;


import lombok.Data;
@Data public class RoleDto { private Long roleid; private String name; }
